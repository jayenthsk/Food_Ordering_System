Food ordering website for small scale restaurants and cloud kitchens which enables customers to order food
from the menu and let's admin to view orders, change menu, etc.

Database credentials:

USER : 'newuser'
PASSWORD : '123'

USER : 'admin'
PASSWORD : '12345'
